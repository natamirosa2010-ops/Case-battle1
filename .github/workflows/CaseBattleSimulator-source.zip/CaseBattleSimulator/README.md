# Case Battle Simulator (Android)

Native Kotlin + Jetpack Compose project. Offline virtual economy only: no Steam login, networking, payments, deposits or cash-out. First launch starts at 5000 virtual rubles. Progress is saved locally with Preferences DataStore.

## Build APK
Requirements: Android Studio (Ladybug or newer), JDK 17+, Android SDK Platform 35.

1. Open this folder in Android Studio.
2. Allow Gradle sync to download Android Gradle Plugin and Compose dependencies.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

Command line (after Android SDK and Gradle dependencies are available): `gradle assembleDebug`.

## Notes
- Minimum Android version: Android 10 (API 29).
- Case artwork is represented with native emoji/gradient illustrations, so the game runs offline without remote assets.
- Virtual items have no real-world value.
